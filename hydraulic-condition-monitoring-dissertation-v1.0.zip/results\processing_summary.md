# Hydraulic Dataset Processing Summary

This file records the reproducible outputs generated from the uploaded UCI hydraulic condition-monitoring dataset.

## Dataset Verification

- Files checked: 18
- All row checks passed: True
- All column checks passed: True

## Label Distribution

| target               | state | count | percentage |
| -------------------- | ----- | ----- | ---------- |
| cooler_condition     | 3     | 732   | 33.2       |
| cooler_condition     | 20    | 732   | 33.2       |
| cooler_condition     | 100   | 741   | 33.61      |
| valve_condition      | 73    | 360   | 16.33      |
| valve_condition      | 80    | 360   | 16.33      |
| valve_condition      | 90    | 360   | 16.33      |
| valve_condition      | 100   | 1125  | 51.02      |
| pump_leakage         | 0     | 1221  | 55.37      |
| pump_leakage         | 1     | 492   | 22.31      |
| pump_leakage         | 2     | 492   | 22.31      |
| accumulator_pressure | 90    | 808   | 36.64      |
| accumulator_pressure | 100   | 399   | 18.1       |
| accumulator_pressure | 115   | 399   | 18.1       |
| accumulator_pressure | 130   | 599   | 27.17      |
| stable_flag          | 0     | 1449  | 65.71      |
| stable_flag          | 1     | 756   | 34.29      |

## Top Exploratory Eta-Squared Features

| target               | rank_within_target | feature   | eta_squared |
| -------------------- | ------------------ | --------- | ----------- |
| accumulator_pressure | 1                  | FS1_max   | 0.196094    |
| accumulator_pressure | 2                  | FS1_range | 0.196093    |
| accumulator_pressure | 3                  | PS3_max   | 0.123346    |
| accumulator_pressure | 4                  | PS3_range | 0.123346    |
| accumulator_pressure | 5                  | EPS1_mean | 0.116343    |
| pump_leakage         | 1                  | FS1_mean  | 0.193453    |
| pump_leakage         | 2                  | EPS1_mean | 0.188524    |
| pump_leakage         | 3                  | PS3_mean  | 0.136266    |
| pump_leakage         | 4                  | PS2_std   | 0.134183    |
| pump_leakage         | 5                  | PS1_max   | 0.115593    |
| stable_flag          | 1                  | FS1_max   | 0.084636    |
| stable_flag          | 2                  | FS1_range | 0.084635    |
| stable_flag          | 3                  | FS1_mean  | 0.083272    |
| stable_flag          | 4                  | PS2_std   | 0.071802    |
| stable_flag          | 5                  | EPS1_mean | 0.071636    |
| valve_condition      | 1                  | FS1_max   | 0.097783    |
| valve_condition      | 2                  | FS1_range | 0.097783    |
| valve_condition      | 3                  | PS2_std   | 0.047194    |
| valve_condition      | 4                  | FS1_mean  | 0.043718    |
| valve_condition      | 5                  | EPS1_mean | 0.036768    |

## Dissertation Use

Use these outputs as benchmark-level hydraulic evidence. Do not interpret them as aircraft-certified maintenance thresholds.